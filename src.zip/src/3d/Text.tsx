import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader';
import {useLoader} from '@react-three/fiber';

const Text = () => {

    const gltf = useLoader(GLTFLoader, '/teapot.gltf')
    return <primitive object={gltf.scene} />
};

export default Text;