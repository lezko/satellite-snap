import Text from '3d/Text';
import {Canvas} from '@react-three/fiber';
import {OrbitControls} from '@react-three/drei';
import Map from 'map/Map';

function App() {
    return (
        <div>
            {/*<Canvas>*/}
            {/*    <Text />*/}
            {/*    <OrbitControls />*/}
            {/*</Canvas>*/}
            <Map />
            <Text />
        </div>
    );
}

export default App;
