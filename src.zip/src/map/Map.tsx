import {GoogleMap, MarkerF, RectangleF, useLoadScript} from '@react-google-maps/api';
import {useMemo} from 'react';

const Map = () => {
    const {isLoaded} = useLoadScript({
        googleMapsApiKey: '',
    });
    const center = useMemo(() => ({lat: 18.52043, lng: 73.856743}), []);

    return (
        <div>
            {!isLoaded ? (
                <h1>Loading...</h1>
            ) : (
                <GoogleMap
                    mapContainerClassName="map"
                    center={center}
                    options={{}}

                    zoom={10}
                >

                    <RectangleF
                        onDrag={e => {
                            console.log(e);
                        }}
                        onBoundsChanged={() => {
                            // console.log(1);
                        }}
                        options={{
                        bounds: {
                            north: 44.599,
                            south: 44.490,
                            east: -78.443,
                            west: -78.649
                        },
                        strokeColor: 'orange',

                        editable: true,
                        draggable: true
                    }} />
                    <MarkerF
                        position={{lat: 18.52043, lng: 73.856743}}
                        icon={'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png'}
                    />

                </GoogleMap>
            )}
        </div>
    );
};
export default Map;